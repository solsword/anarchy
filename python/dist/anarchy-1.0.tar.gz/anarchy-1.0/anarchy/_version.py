"""
Package version number.

_version.py
"""

__version__ = "1.0"
